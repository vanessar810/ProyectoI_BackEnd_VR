package dh.backend.ClinicaOdontologicaVR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicaOdontologicaVrApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClinicaOdontologicaVrApplication.class, args);
	}

}
