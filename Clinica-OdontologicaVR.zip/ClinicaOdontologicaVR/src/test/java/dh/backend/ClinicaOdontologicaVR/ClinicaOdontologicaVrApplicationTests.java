package dh.backend.ClinicaOdontologicaVR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClinicaOdontologicaVrApplicationTests {

	@Test
	void contextLoads() {
	}

}
